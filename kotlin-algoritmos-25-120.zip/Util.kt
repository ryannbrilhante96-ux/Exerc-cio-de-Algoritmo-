fun lerInt(mensagem: String): Int {
    print(mensagem)
    return readln().trim().toInt()
}

fun lerDouble(mensagem: String): Double {
    print(mensagem)
    return readln().trim().replace(',', '.').toDouble()
}

fun lerTexto(mensagem: String): String {
    print(mensagem)
    return readln()
}

fun dinheiro(valor: Double): String = "%.2f".format(valor)
